# JupyterLab on a compute node inside an Apptainer container. HPCWizard adds the #SBATCH header.
# Placeholders are replaced with shell-quoted values before the job is submitted:
#   {{IMAGE}}     path to the .sif image (a leading ~ or $HOME is expanded here)
#   {{STORAGE}}   storage folder on the cluster (same expansion)
#   {{ENV_NAME}}  name of the permanent virtual environment (one per image)
#   {{KEEP}}      1: permanent environment in STORAGE/envs, 0: temporary one removed at the end
#   {{PACKAGES}}  extra pip packages, space separated (intentionally word-split)
#   {{TOKEN}}     Jupyter access token (an env var, so `ps` on the shared node does not show it)
set -euo pipefail
# Jupyter and pip log to stderr; merge it so HPCWizard sees everything in the followed stdout log.
exec 2>&1

# HPCWizard reads these lines to learn the node, the port and the progress.
echo "HPCWIZARD_NODE=$(hostname)"

IMAGE={{IMAGE}}
STORAGE={{STORAGE}}
ENV_NAME={{ENV_NAME}}
KEEP={{KEEP}}
PACKAGES={{PACKAGES}}

# Quoted values are not expanded by bash, so expand a leading ~ or $HOME here.
IMAGE="${IMAGE/#\~/$HOME}"
IMAGE="${IMAGE/#\$HOME/$HOME}"
STORAGE="${STORAGE/#\~/$HOME}"
STORAGE="${STORAGE/#\$HOME/$HOME}"

export PIP_NO_CACHE_DIR=1 PYTHONNOUSERSITE=1
export JUPYTER_TOKEN={{TOKEN}}

if [ "$KEEP" = "1" ]; then
  VENV="$STORAGE/envs/$ENV_NAME"
else
  VENV="${TMPDIR:-/tmp}/hpcw-nb-$SLURM_JOB_ID"
  trap 'rm -rf "$VENV"' EXIT
  trap 'exit 143' TERM INT
fi

run() { apptainer exec --nv "$IMAGE" "$@"; }

echo "HPCWIZARD_STAGE=Preparing the environment…"
mkdir -p "$(dirname "$VENV")"
[ -x "$VENV/bin/python" ] || run python -m venv --system-site-packages "$VENV"

if [ -n "$PACKAGES" ]; then
  echo "HPCWIZARD_STAGE=Installing packages…"
  # Intentionally word-split: one argument per package.
  run "$VENV/bin/pip" install $PACKAGES
fi

PORT=$(run "$VENV/bin/python" -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));print(s.getsockname()[1])')
echo "HPCWIZARD_PORT=$PORT"
echo "HPCWIZARD_STAGE=Starting JupyterLab…"
echo "HPCWIZARD_READY_SOON"

# Not exec'd, so the temporary-environment trap still runs. The venv's python makes it the default kernel.
run "$VENV/bin/python" -m jupyterlab --no-browser --ip=127.0.0.1 --port="$PORT" \
  --ServerApp.port_retries=0 --ServerApp.root_dir="$HOME"
