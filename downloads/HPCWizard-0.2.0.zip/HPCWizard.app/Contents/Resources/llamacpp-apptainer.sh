# Default llama.cpp server script (Apptainer). HPCWizard adds the #SBATCH header.
# Placeholders are replaced with shell-quoted values before the job is submitted:
#   {{MODEL_PATH}}  Hugging Face repo (org/model:quant) or a path on the cluster
#   {{CONTAINER}}   path to the llama.cpp .sif image
#   {{PORT}}        port the server listens on (on the compute node)
#   {{CONTEXT}}     context size in tokens
#   {{GPUS}}        GPUs requested
#   {{CPUS}}        CPUs requested
set -euo pipefail

# HPCWizard reads this line to learn which node the job runs on.
echo "HPCWIZARD_NODE=$(hostname)"

MODEL={{MODEL_PATH}}
CONTAINER={{CONTAINER}}
PORT={{PORT}}
CONTEXT={{CONTEXT}}
GPUS={{GPUS}}
CPUS={{CPUS}}

# Quoted values are not expanded by bash, so expand a leading ~ or $HOME here.
CONTAINER="${CONTAINER/#\~/$HOME}"
CONTAINER="${CONTAINER/#\$HOME/$HOME}"

# A path (/..., ~..., $...) is loaded as a local file, anything else is downloaded from Hugging Face.
case "$MODEL" in
  /* | \~* | \$*)
    MODEL="${MODEL/#\~/$HOME}"
    MODEL="${MODEL/#\$HOME/$HOME}"
    MODEL_ARGS=(-m "$MODEL") ;;
  *)
    MODEL_ARGS=(-hf "$MODEL") ;;
esac

apptainer exec --nv "$CONTAINER" llama-server "${MODEL_ARGS[@]}" \
  --host 127.0.0.1 --port "$PORT" -c "$CONTEXT" -ngl 999 -t "$CPUS"
